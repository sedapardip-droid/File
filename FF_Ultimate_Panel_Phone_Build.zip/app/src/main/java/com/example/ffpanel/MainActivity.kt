package com.example.ffpanel

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val red = Color.rgb(255,35,65)
    private val bg = Color.rgb(10,8,12)
    private fun shape(color:Int, stroke:Int=0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius=18f
        if(stroke!=0) setStroke(2,stroke)
    }
    private fun text(s:String,size:Float,color:Int=Color.WHITE,bold:Boolean=false)=TextView(this).apply {
        text=s; textSize=size; setTextColor(color); if(bold) typeface=Typeface.DEFAULT_BOLD
        setPadding(12,8,12,8)
    }
    private fun section(title:String): TextView = text("✦  $title",17f,red,true).apply {
        background=shape(Color.rgb(22,12,18),red); setPadding(14,12,14,12)
    }
    private fun toggle(label:String): Switch = Switch(this).apply {
        text=label; textSize=15f; setTextColor(Color.WHITE); buttonTintList=null
        thumbTintList=android.content.res.ColorStateList.valueOf(red)
        trackTintList=android.content.res.ColorStateList.valueOf(Color.DKGRAY)
        setPadding(8,6,8,6)
    }
    private fun addToggle(box:LinearLayout,label:String,enabled:Boolean=false) {
        val sw=toggle(label); sw.isChecked=enabled; box.addView(sw)
    }
    private fun panel(title:String):LinearLayout=LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(12,8,12,8); background=shape(Color.rgb(15,12,17),red)
        addView(section(title))
    }
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor=Color.BLACK; window.navigationBarColor=Color.BLACK
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(12,12,12,12) }
        val scroll=ScrollView(this); val content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        val head=text("👑  FREE FIRE\nULTIMATE PANEL  v10.0\nAim Practice • Visual Simulator",23f,Color.WHITE,true).apply {
            gravity=Gravity.CENTER; background=shape(Color.rgb(24,5,12),red); setPadding(12,22,12,22)
        }
        content.addView(head)
        val tabs=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
        listOf("COMBAT","ESP","TELEPORT","MORE").forEach { t ->
            val b=Button(this).apply { text=t; textSize=11f; setTextColor(Color.WHITE); background=shape(Color.rgb(55,5,15),red) }
            tabs.addView(b,LinearLayout.LayoutParams(0,54,1f))
        }
        content.addView(tabs)
        val combat=panel("COMBAT • TRAINING SIMULATOR")
        listOf("Aimbot Head (practice only)","Silent Aim (aim drill)","Drag Headshot Trainer","No Recoil Trainer","No Spread Simulator").forEach { addToggle(combat,it) }
        combat.addView(text("FOV  •  120°",15f,red,true))
        val seek=SeekBar(this).apply { max=180; progress=120; progressTintList=android.content.res.ColorStateList.valueOf(red); thumbTintList=android.content.res.ColorStateList.valueOf(red) }
        combat.addView(seek); content.addView(combat)
        val esp=panel("ESP • TARGET VISUALIZER")
        listOf("ESP Box","ESP Line","ESP Skeleton","ESP Health","ESP Name","ESP Distance","ESP Items").forEach { addToggle(esp,it) }
        val styles=TextView(this).apply { text="Style:  NORMAL  •  GLOW  •  CORNER  •  SKELETON"; setTextColor(red); textSize=13f; setPadding(8,12,8,12) }; esp.addView(styles); content.addView(esp)
        val tp=panel("TELEPORT • SANDBOX")
        addToggle(tp,"Teleport Map (sandbox marker)")
        addToggle(tp,"Teleport Plane (BR route preview)")
        tp.addView(text("Map / plane options are visual sandbox controls only.",12f,Color.LTGRAY)); content.addView(tp)
        val misc=panel("MISC FEATURES • SIMULATION")
        listOf("Freeze (dummy target)","Fake Lag (network demo)","Speed Hack (local movement demo)","Extra Training Overlay").forEach { addToggle(misc,it) }
        content.addView(misc)
        content.addView(text("✓ PANEL READY • TRAIN SAFELY",16f,Color.GREEN,true).apply { gravity=Gravity.CENTER; setPadding(12,18,12,18) })
        scroll.addView(content); root.addView(scroll); setContentView(root)
    }
}
